import React from "react";
import ReactDOM from "react-dom";

const min = ["1", "7", "3", "8", "2", "5"]
  .map((item) => parseInt(item, 10))
  .filter((item) => item % 2)
  .reduce((item, summ) => (summ = summ + item));
console.log("min from arrow! = " + min);

function newarray(a, ...items){
console.log(a, items);
}
newarray(1,2,5,8,15,6);


function TodoItem() {
  return <span>_!!! Drink Cofee!</span>;
}

function TodoList() {
  return (
    <ul>
      <li>
        <TodoItem />
      </li>
      <li>
        <TodoItem />
      </li>
      <li>
        <TodoItem />
      </li>
    </ul>
  );
}

ReactDOM.render(<TodoList />, document.getElementById("root"));
